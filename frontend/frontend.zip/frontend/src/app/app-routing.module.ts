import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { GuestComponent } from './guest/guest.component';
import { AdminGuardGuard } from './admin-guard.guard';
import { UserGuardGuard } from './user-guard.guard';
import { RegisterComponent } from './register/register.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserChangePasswordComponent } from './user-change-password/user-change-password.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { UserBooksComponent } from './user-books/user-books.component';
import { UserEventsComponent } from './user-events/user-events.component';
import { UserBookComponent } from './user-book/user-book.component';
import { UserViewUserComponent } from './user-view-user/user-view-user.component';
import { UserAddBookComponent } from './user-add-book/user-add-book.component';
import { UserUsersComponent } from './user-users/user-users.component';
import { UserAddEventComponent } from './user-add-event/user-add-event.component';
import { GuestBooksComponent } from './guest-books/guest-books.component';
import { GuestBookComponent } from './guest-book/guest-book.component';
import { GuestEventsComponent } from './guest-events/guest-events.component';
import { ModeratorComponent } from './moderator/moderator.component';
import { ModeratorBooksComponent } from './moderator-books/moderator-books.component';
import { ModeratorBookComponent } from './moderator-book/moderator-book.component';
import { AdminBookComponent } from './admin-book/admin-book.component';
import { AdminViewUserComponent } from './admin-view-user/admin-view-user.component';
import { AdminAddBookComponent } from './admin-add-book/admin-add-book.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminAddUserComponent } from './admin-add-user/admin-add-user.component';
import { AdminBooksComponent } from './admin-books/admin-books.component';
import { AdminGenresComponent } from './admin-genres/admin-genres.component';
import { ModeratorAddBookComponent } from './moderator-add-book/moderator-add-book.component';
import { UserEventComponent } from './user-event/user-event.component';


const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'admin', component: AdminComponent, canActivate: [AdminGuardGuard],
    children: [
      {path: 'admin-change-password', component: UserChangePasswordComponent},
      {path: '', component: UserInfoComponent},
      {path: 'admin-books', component: AdminBooksComponent},
      {path: 'admin-events', component: UserEventsComponent},
      {path: 'user-book', component: AdminBookComponent},
      {path: 'admin-view-user', component: AdminViewUserComponent},
      {path: 'admin-add-book', component: AdminAddBookComponent},
      {path: 'admin-add-event', component: UserAddEventComponent},
      {path: 'admin-users', component: AdminUsersComponent},
      {path: 'admin-add-user', component: AdminAddUserComponent},
      {path: 'admin-genres', component: AdminGenresComponent},
      {path: 'admin-event', component: UserEventComponent}
    ]
  },
  {path: 'user', component: UserComponent, canActivate: [UserGuardGuard],
    children: [
      {path: 'user-change-password', component: UserChangePasswordComponent},
      {path: '', component: UserInfoComponent},
      {path: 'user-books', component: UserBooksComponent},
      {path: 'user-events', component: UserEventsComponent},
      {path: 'user-book', component: UserBookComponent},
      {path: 'user-view-user', component: UserViewUserComponent},
      {path: 'user-add-book', component: UserAddBookComponent},
      {path: 'user-add-event', component: UserAddEventComponent},
      {path: 'user-users', component: UserUsersComponent},
      {path: 'user-event', component: UserEventComponent}
    ]
  },
  {path: 'guest', component: GuestComponent, 
    children: [
      {path: 'guest-book', component: GuestBookComponent},
      {path: 'guest-books', component: GuestBooksComponent},
      {path: 'guest-events', component: GuestEventsComponent}
    ]
  },
  {path: 'moderator', component: ModeratorComponent,
    children: [
      {path: 'moderator-change-password', component: UserChangePasswordComponent},
      {path: '', component: UserInfoComponent},
      {path: 'moderator-books', component: ModeratorBooksComponent},
      {path: 'moderator-events', component: UserEventsComponent},
      {path: 'user-book', component: ModeratorBookComponent},
      {path: 'user-view-user', component: UserViewUserComponent},
      {path: 'user-add-book', component: ModeratorAddBookComponent},
      {path: 'moderator-add-event', component: UserAddEventComponent},
      {path: 'user-users', component: UserUsersComponent},
      {path: 'moderator-event', component: UserEventComponent}
    ]
  },
  {path: 'register', component: RegisterComponent},
  {path: 'reset-password', component: ResetPasswordComponent},
  {path: 'reset-password/:id', component: ChangePasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
