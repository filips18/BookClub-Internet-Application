import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { MyComment } from '../models/comment';
import { Book } from '../models/book';

@Component({
  selector: 'app-guest-books',
  templateUrl: './guest-books.component.html',
  styleUrls: ['./guest-books.component.css']
})
export class GuestBooksComponent implements OnInit {

  constructor(private service: BookService, private router: Router, private service2: UserService) { }

  ngOnInit(): void {
    //knjige
    this.service.getBooks().subscribe(res => {this.booksArr = res; this.booksArrFiltered = res});
    setTimeout(() => {
      // 
      this.service2.getComments().subscribe(res => this.comments = res);
      //prodji kroz sve knjige
      this.booksArr.forEach(element => {
        //prodji kroz sve zanrove knjige
        element.genres.forEach(elGenres => {
          let foundGenre : boolean = false;
          //vidi da li se taj zanr vec nalazi u nizu svih zanrova, ako ne onda ga dodaj
          this.genresArr.forEach(elGenresArr => {
            if(!elGenresArr.localeCompare(elGenres)) foundGenre = true;
          });
          //ako ga nije nasao dodaj ga
          if(!foundGenre) this.genresArr.push(elGenres);
        });
      });
    }, 100);
  }
  //
  booksArr: Book[] = [];
  booksArrFiltered: Book[] = [];
  //
  author: string = "";
  title: string = "";
  genres: string[] = [];
  genresArr: string[] = [];
  comments: MyComment[];
  //pretrazi knjige
  search() {
    //resetuj search
    this.booksArrFiltered = [];
    //
    this.booksArr.forEach(element=>{
      if(this.title == "" || this.title == undefined || element.title.toLocaleLowerCase().indexOf(this.title.toLocaleLowerCase()) != -1) {
        //jel ok autor
        let foundAuth : boolean = false;
        if(this.author == "" || this.author == undefined) foundAuth = true;
        else {
          element.authors.forEach(auth => {
            if(auth.toLocaleLowerCase().indexOf(this.author.toLocaleLowerCase()) != -1) foundAuth = true;
          });
        }
        //nasao autora, vidi je l se poklapa neki zanr
        if(foundAuth) {
          let foundGenre: boolean = false;
          element.genres.forEach(genre => {
            this.genres.forEach(genre2 => {
              if(genre2 && !genre.localeCompare(genre2)) {
                foundGenre = true;
              }
            });
          });
          //sve ok, ubaci knjigu i niz filtriranih
          if(foundGenre) this.booksArrFiltered.push(element);
        }
      }
    });
  }
  //
  openBook(bk: Book) {
    localStorage.setItem("openedBook", JSON.stringify(bk));
    this.router.navigate(['/guest/guest-book']);
  }
}
