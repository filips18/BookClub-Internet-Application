import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestBooksComponent } from './guest-books.component';

describe('GuestBooksComponent', () => {
  let component: GuestBooksComponent;
  let fixture: ComponentFixture<GuestBooksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuestBooksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestBooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
