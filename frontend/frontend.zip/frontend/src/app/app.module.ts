import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { GuestComponent } from './guest/guest.component';
import { AdminGuardGuard } from './admin-guard.guard';
import { HttpClientModule } from '@angular/common/http';
import { UserGuardGuard } from './user-guard.guard';
import { RecaptchaModule, RecaptchaFormsModule} from 'ng-recaptcha';
import { ModeratorComponent } from './moderator/moderator.component';
import { UserChangePasswordComponent } from './user-change-password/user-change-password.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { UserBooksComponent } from './user-books/user-books.component';
import { UserEventsComponent } from './user-events/user-events.component';
import { GuestBooksComponent } from './guest-books/guest-books.component';
import { GuestEventsComponent } from './guest-events/guest-events.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import { UserBookComponent } from './user-book/user-book.component';
import { UserViewUserComponent } from './user-view-user/user-view-user.component';
import { UserAddBookComponent } from './user-add-book/user-add-book.component';
import { UserAddEventComponent } from './user-add-event/user-add-event.component';
import { UserUsersComponent } from './user-users/user-users.component';
import { GuestBookComponent } from './guest-book/guest-book.component';
import { ModeratorBookComponent } from './moderator-book/moderator-book.component';
import { ModeratorBooksComponent } from './moderator-books/moderator-books.component';
import { AdminBookComponent } from './admin-book/admin-book.component';
import { AdminViewUserComponent } from './admin-view-user/admin-view-user.component';
import { AdminAddBookComponent } from './admin-add-book/admin-add-book.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminAddUserComponent } from './admin-add-user/admin-add-user.component';
import { AdminBooksComponent } from './admin-books/admin-books.component';
import { AdminGenresComponent } from './admin-genres/admin-genres.component';
import { ModeratorAddBookComponent } from './moderator-add-book/moderator-add-book.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserEventComponent } from './user-event/user-event.component';
import {MatStepperModule} from '@angular/material/stepper';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ResetPasswordComponent,
    ChangePasswordComponent,
    AdminComponent,
    UserComponent,
    GuestComponent,
    ModeratorComponent,
    UserChangePasswordComponent,
    UserInfoComponent,
    UserBooksComponent,
    UserEventsComponent,
    GuestBooksComponent,
    GuestEventsComponent,
    UserBookComponent,
    UserViewUserComponent,
    UserAddBookComponent,
    UserAddEventComponent,
    UserUsersComponent,
    GuestBookComponent,
    ModeratorBookComponent,
    ModeratorBooksComponent,
    AdminBookComponent,
    AdminViewUserComponent,
    AdminAddBookComponent,
    AdminUsersComponent,
    AdminAddUserComponent,
    AdminBooksComponent,
    AdminGenresComponent,
    ModeratorAddBookComponent,
    UserEventComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RecaptchaModule ,
    RecaptchaFormsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    NgbModule,
    MatStepperModule,
    MatSelectModule
  ],
  providers: [AdminGuardGuard, UserGuardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
