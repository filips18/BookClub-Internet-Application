import { Component, OnInit } from '@angular/core';
import { Book } from '../models/book';
import { BookService } from '../book.service';
import { Genre } from '../models/genre';

@Component({
  selector: 'app-moderator-add-book',
  templateUrl: './moderator-add-book.component.html',
  styleUrls: ['./moderator-add-book.component.css']
})
export class ModeratorAddBookComponent implements OnInit {

  constructor(private service: BookService) { }

  ngOnInit(): void {
    this.service.getBooks().subscribe(res => this.booksArr = res);
    //
    this.service.getGenres().subscribe(res => this.genresArr = res);
  }

  //
  myBook: Book = new Book();
  booksArr: Book[] = [];
  genresArr: Genre[] = [];
  //
  success: boolean = false;
  missingFields: boolean = false;
  tooManyGenres: boolean = false;
  profilePicture: File = null;
  //
  myAuthors: string;
  //
  updatePicture(fs:File[]) {
    this.profilePicture = fs[0];
  }
  
  //dodaj knjigu
  addBook() {
    //
    this.success = false;
    this.missingFields = false;
    //
    if(this.myBook.title == undefined || this.myAuthors == undefined || this.myAuthors.length == 0  || this.myBook.genres == undefined || this.myBook.genres.length == 0 || this.myBook.dateOfPublishing == undefined) {
      this.missingFields = true;
      return;
    }
    if(this.myBook.genres.length > 3) {
      this.tooManyGenres = true;
      return;
    }
    //
    if(this.myBook.description == undefined) this.myBook.description = " ";
    this.myBook.approved = true;
    this.myBook.averageScore = 0;
    this.myBook.authors = this.myAuthors.split(',');
    //
    if(this.profilePicture == null) {
      this.myBook.titlePicture = "../../assets/bookPictures/defaultBookTitlePicture.jpg";
    }
    else {
      this.myBook.titlePicture = "../../assets/bookPictures/"  + this.profilePicture.name;//ovde fzn nema jedinstvenosti imena slike
      let uploadOK = false;
      this.service.uploadFile(this.profilePicture).subscribe(res => uploadOK = res);
      /*if(!uploadOK) {
        alert("Error while uploading file!");
      }*/
    }
    this.service.addBook(this.myBook).subscribe(res => this.success = res);
    this.booksArr.push(this.myBook);
    this.myBook = new Book;
  }
}

