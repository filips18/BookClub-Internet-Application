import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModeratorAddBookComponent } from './moderator-add-book.component';

describe('ModeratorAddBookComponent', () => {
  let component: ModeratorAddBookComponent;
  let fixture: ComponentFixture<ModeratorAddBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorAddBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModeratorAddBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
