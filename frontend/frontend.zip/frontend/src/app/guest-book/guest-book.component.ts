import { Component, OnInit } from '@angular/core';
import { MyComment } from '../models/comment';
import { Book } from '../models/book';
import { UserService } from '../user.service';

@Component({
  selector: 'app-guest-book',
  templateUrl: './guest-book.component.html',
  styleUrls: ['./guest-book.component.css']
})
export class GuestBookComponent implements OnInit {

  constructor(private service: UserService) { }

  ngOnInit(): void {
    //komentari
    this.service.getComments().subscribe(res => this.commentArr = res);
    this.thisBook = JSON.parse(localStorage.getItem("openedBook"));
  }

  //
  commentArr: MyComment[] = [];
  thisBook: Book;
}
