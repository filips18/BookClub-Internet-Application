import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddEventComponent } from './user-add-event.component';

describe('UserAddEventComponent', () => {
  let component: UserAddEventComponent;
  let fixture: ComponentFixture<UserAddEventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAddEventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAddEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
