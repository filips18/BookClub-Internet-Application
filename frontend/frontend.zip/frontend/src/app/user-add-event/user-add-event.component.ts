import { Component, OnInit } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { EventService } from '../event.service';
import { MyEvent } from '../models/event';
import { User } from '../models/user';


@Component({
  selector: 'app-user-add-event',
  templateUrl: './user-add-event.component.html',
  styleUrls: ['./user-add-event.component.css']
})
export class UserAddEventComponent implements OnInit {
  constructor(private service: EventService) {}

  ngOnInit() {
    //
    this.loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    if(!this.loggedInUser.type.localeCompare("user")) this.addParticipants = true;
  }

  newEvent: MyEvent = new MyEvent();
  requiredFields: boolean = false;
  addParticipants: boolean = false;
  loggedInUser: User;
  //
  activities: string = "";

  addEvent() {
    this.requiredFields = false;
    //
    if(!this.newEvent.name || !this.newEvent.description || !this.activities || !this.activities.localeCompare("")) {
      this.requiredFields = true;
      return;
    }
    let loggedInUser: User = JSON.parse(localStorage.getItem("loggedInUser"));
    if(!loggedInUser.type.localeCompare("user")) this.newEvent.public = false;
    else this.newEvent.public = true;
    //
    this.newEvent.activities = this.activities.split(",");
    //
    if(!this.newEvent.startDate) this.newEvent.startDate = new Date();
    if(!this.newEvent.participants) this.newEvent.participants = [];
    //
    this.newEvent.closed = false;
    this.newEvent.madeByUser = loggedInUser.username;
    this.newEvent.requests = [];
    //
    this.service.addEvent(this.newEvent).subscribe();
    alert("Event added!");
  }
}
