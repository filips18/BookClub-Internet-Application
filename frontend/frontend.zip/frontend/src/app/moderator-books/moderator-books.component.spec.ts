import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModeratorBooksComponent } from './moderator-books.component';

describe('ModeratorBooksComponent', () => {
  let component: ModeratorBooksComponent;
  let fixture: ComponentFixture<ModeratorBooksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorBooksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModeratorBooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
