import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css']
})
export class AdminUsersComponent implements OnInit {

  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.service.getUsers().subscribe(res => {this.userArr = res; this.userArrFiltered = res;});
  }

  //userArrs
  thisUser: User;
  userArr: User[] = [];
  userArrFiltered: User[] = [];
  //search param
  firstName: string;
  lastName: string;
  username: string;
  email: string;

  //
  search() {
    this.userArrFiltered = [];
    this.userArr.forEach(element => {
      let insertedElem : boolean = false;
      //search parametri
      if(this.firstName == undefined || this.firstName == "" || !element.firstName.localeCompare(this.firstName)) {
        //
        if(this.lastName == undefined || this.lastName == "" || !element.lastName.localeCompare(this.lastName)) {
          //
          if(this.username == undefined || this.username == "" || !element.username.localeCompare(this.username)) {
            insertedElem = true;
            this.userArrFiltered.push(element);
          }
        }
      }
      //ili email
      if(!insertedElem && !element.email.localeCompare(this.email)) {
        this.userArrFiltered.push(element);
      }
    });
  }
  //
  openUser(usr: User) {
    localStorage.setItem("openedUser", JSON.stringify(usr));
  }
  //
  approve(usr: User) {
    usr.approved = true;
    this.service.updateUser(usr).subscribe();
  }
}
