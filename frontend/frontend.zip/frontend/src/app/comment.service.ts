import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MyComment } from './models/comment';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private http: HttpClient) { }

  urlUpdateComment = "http://localhost:3000/api/comment/";//dodajes id komentara na ovo kad radis update
  urlAddComment = "http://localhost:3000/api/comment/";

  updateComment(com: MyComment){
    console.log(com);
    return this.http.put<boolean>(this.urlUpdateComment + com._id, com);
  }

  //add user, or request
  addComment(comm: MyComment){
    return this.http.post<boolean>(this.urlAddComment, comm);
  }
}
