import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModeratorBookComponent } from './moderator-book.component';

describe('ModeratorBookComponent', () => {
  let component: ModeratorBookComponent;
  let fixture: ComponentFixture<ModeratorBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModeratorBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
