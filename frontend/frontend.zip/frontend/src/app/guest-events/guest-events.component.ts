import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { MyEvent } from '../models/event';

@Component({
  selector: 'app-guest-events',
  templateUrl: './guest-events.component.html',
  styleUrls: ['./guest-events.component.css']
})
export class GuestEventsComponent implements OnInit {

  constructor(private service: EventService) { }

  ngOnInit(): void {
    this.service.getEvents().subscribe(res => this.eventArr = res);
    setTimeout(() => {
      this.eventArr.forEach(element => {
        element.startDate = new Date(element.startDate);
        if(element.endDate) element.endDate = new Date(element.endDate);
        if(element.endDate && element.endDate < this.currDate) {
          element.closed = true;
        }
      })
    }, 100);
  }

  //
  eventArr: MyEvent[];
  currDate: Date = new Date();
}
