import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddBookComponent } from './user-add-book.component';

describe('UserAddBookComponent', () => {
  let component: UserAddBookComponent;
  let fixture: ComponentFixture<UserAddBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAddBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAddBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
