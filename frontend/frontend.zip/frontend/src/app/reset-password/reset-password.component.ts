import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../models/user';
import { element } from 'protractor';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  constructor(private service : UserService) { }

  ngOnInit(): void {
    this.service.getUsers().subscribe(users => this.userArray = users);
  }

  userArray: User[]; 
  //
  email: string = "";
  emailInvalid: boolean = false;
  success: boolean = false;

  sendMail() {
    this.emailInvalid = true;
    this.success = false;
    this.userArray.forEach(element =>{
      if(!element.email.localeCompare(this.email) && element.approved) this.emailInvalid = false; 
    });
    if(!this.emailInvalid) {
      this.service.sendMail(this.email).subscribe(res => this.success = res);
    }
  }
}
