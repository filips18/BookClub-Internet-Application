import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from "./models/user";
import { MyComment } from './models/comment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  urlGetUsers = "http://localhost:3000/api/users";
  urlGetComments = "http://localhost:3000/api/comments";
  urlPostFile = "http://localhost:3000/api/file";
  urlCheckToken = "http://localhost:3000/api/token_validate";
  urlAddUser = "http://localhost:3000/api/user";
  urlSendMail = "http://localhost:3000/api/forgot-password";
  urlUpdateUser = "http://localhost:3000/api/user/";//dodajes id na ovo dole u funkcijama

  //retrieve users
  getUsers(){
    return this.http.get<User[]>(this.urlGetUsers);
  }

  //
  getComments(){
    return this.http.get<MyComment[]>(this.urlGetComments);
  }

  //add user, or request
  addUser(user: User){
    return this.http.post<boolean>(this.urlAddUser, user);
  }

  //check if admin is logged in
  loggedInAdmin(){
    let loggedInUser : User = JSON.parse(localStorage.getItem("loggedInUser"));
    if(loggedInUser != null && !loggedInUser.type.localeCompare("admin")) {
      return true;
    }
    return false;
  }
  
  //check if user is logged in
  loggedInUser(){
    let loggedInUser : User = JSON.parse(localStorage.getItem("loggedInUser"));
    if(loggedInUser != null && !loggedInUser.type.localeCompare("user")) {
      return true;
    }
    return false;
  }

  //upload profile picture
  uploadFile(f : File, username: string) : Observable<boolean> {
    const formData: FormData = new FormData();
    formData.append('fileKey', f, username + f.name);
    return this.http
      .post<boolean>(this.urlPostFile, formData);
  }

  //send email for pass reset
  sendMail(email: string) {
    console.log(email);
    return this.http.put<boolean>(this.urlSendMail,{'email' : email});
  }

  //reset password for user with given id
  updateUser(user: User) {
    return this.http.put<boolean>(this.urlUpdateUser + user._id, user);
  }

  //recaptcha token
  sendToken(token): Observable<boolean>{
    return this.http.post<boolean>(this.urlCheckToken, {recaptcha: token})
  }
}
