import { Component, OnInit } from '@angular/core';
import { Book } from '../models/book';
import { BookService } from '../book.service';
import { Router } from '@angular/router';
import { MyComment } from '../models/comment';
import { UserService } from '../user.service';
import { User } from '../models/user';
import { Genre } from '../models/genre';

@Component({
  selector: 'app-admin-books',
  templateUrl: './admin-books.component.html',
  styleUrls: ['./admin-books.component.css']
})
export class AdminBooksComponent implements OnInit {
  constructor(private service: BookService, private router: Router, private service2: UserService) { }
  ngOnInit(): void {
    //knjige
    this.service.getBooks().subscribe(res => {this.booksArr = res; this.booksArrFiltered = res});
    //
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    //
    this.service.getGenres().subscribe(res => this.genresArr = res);
    //
    this.service2.getComments().subscribe(res => this.comments = res);
  }
  //
  thisUser: User;
  //
  booksArr: Book[] = [];
  booksArrFiltered: Book[] = [];
  //
  author: string = "";
  title: string = "";
  genres: string[] = [];
  genresArr: Genre[] = [];
  //slika
  profilePicture: File = null;
  //
  myBook: Book = new Book();
  myAuthors: string;
  comments: MyComment[] = [];
  //bulovi
  success: boolean = false;
  missingFields: boolean = false;
  tooManyGenres: boolean = false;
  //pretrazi knjige
  search() {
    //resetuj search
    this.booksArrFiltered = [];
    //
    this.booksArr.forEach(element=>{
      if(this.title == "" || this.title == undefined || element.title.toLocaleLowerCase().indexOf(this.title.toLocaleLowerCase()) != -1) {
        //jel ok autor
        let foundAuth : boolean = false;
        if(this.author == "" || this.author == undefined) foundAuth = true;
        else {
          element.authors.forEach(auth => {
            if(auth.toLocaleLowerCase().indexOf(this.author.toLocaleLowerCase()) != -1) foundAuth = true;
          });
        }
        //nasao autora, vidi je l se poklapa neki zanr
        if(foundAuth) {
          let foundGenre: boolean = false;
          element.genres.forEach(genre => {
            this.genres.forEach(genre2 => {
              if(genre2 && !genre.localeCompare(genre2)) {
                foundGenre = true;
              }
            });
          });
          //sve ok, ubaci knjigu i niz filtriranih
          if(foundGenre) this.booksArrFiltered.push(element);
        }
      }
    });
  }
  updatePicture(fs:File[]) {
    this.profilePicture = fs[0];
  }
  //dodaj knjigu
  addBook() {
    //
    this.success = false;
    this.missingFields = false;
    //
    if(this.myBook.title == undefined || this.myAuthors == undefined || this.myAuthors.length == 0  || this.myBook.genres == undefined || this.myBook.genres.length == 0 || this.myBook.dateOfPublishing == undefined) {
      this.missingFields = true;
      return;
    }
    if(this.myBook.genres.length > 3) {
      this.tooManyGenres = true;
      return;
    }
    //
    if(this.myBook.description == undefined) this.myBook.description = " ";
    this.myBook.approved = true;//ovo je razlika samo u odnosu na usera
    this.myBook.averageScore = 0;
    this.myBook.authors = this.myAuthors.split(',');
    //
    if(this.profilePicture == null) {
      this.myBook.titlePicture = "../../assets/bookPictures/defaultBookTitlePicture.jpg";
    }
    else {
      this.myBook.titlePicture = "../../assets/bookPictures/"  + this.profilePicture.name;//ovde fzn nema jedinstvenosti imena slike
      let uploadOK = false;
      this.service.uploadFile(this.profilePicture).subscribe(res => uploadOK = res);
      /*if(!uploadOK) {
        alert("Error while uploading file!");
      }*/
    }
    this.service.addBook(this.myBook).subscribe(res => this.success = res);
    this.booksArr.push(this.myBook);
    this.myBook = new Book;
  }
  //
  openBook(bk: Book) {
    let myComment: MyComment = null;
    this.comments.forEach(element => {
      if(element.book._id == bk._id && !element.user.localeCompare(this.thisUser.username)) myComment = element;
    });
    if(myComment) localStorage.setItem("myComment", JSON.stringify(myComment));
    else localStorage.removeItem("myComment");
    localStorage.setItem("openedBook", JSON.stringify(bk));
    this.router.navigate(['/admin/user-book']);
  }
  //
  approve(bk: Book) {
    bk.approved = true;
    this.service.updateBook(bk).subscribe();
  }
}
