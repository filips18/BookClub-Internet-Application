import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { MyEvent } from '../models/event';
import { User } from '../models/user';

@Component({
  selector: 'app-user-event',
  templateUrl: './user-event.component.html',
  styleUrls: ['./user-event.component.css']
})
export class UserEventComponent implements OnInit {

  constructor(private service: EventService) { }

  ngOnInit(): void {
    this.canRequest = true;
    this.currDate = new Date();
    this.thisEvent = JSON.parse(localStorage.getItem("openedEvent"));
    this.thisEvent.startDate = new Date(this.thisEvent.startDate);
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    //
    if(this.thisEvent.public) this.canShowActivities = true;
    else if(!this.thisEvent.madeByUser.localeCompare(this.thisUser.username)) this.canShowActivities = true;
    else {
      this.thisEvent.participants.forEach(element => {
        if(!element.localeCompare(this.thisUser.username)) this.canShowActivities = true;
      })
    }
    //
    this.thisEvent.requests.forEach(element =>{
      console.log(element);
      if(!element.localeCompare(this.thisUser.username)) this.canRequest = false;
    });
  }

  //
  thisEvent: MyEvent;
  canShowActivities: boolean = false;
  //
  thisUser: User;
  currDate: Date;
  //
  canRequest: boolean;
  //
  usersToApprove: string[] = [];
  //
  closeEvent() {
    this.thisEvent.closed = true;
    //
    this.service.updateEvent(this.thisEvent).subscribe();
    localStorage.setItem("openedEvent", JSON.stringify(this.thisEvent));
  }

  openEvent() {
    this.thisEvent.closed = false;
    //
    this.service.updateEvent(this.thisEvent).subscribe();
    localStorage.setItem("openedEvent", JSON.stringify(this.thisEvent));
  }

  request() {
    this.thisEvent.requests.push(this.thisUser.username);
    //
    this.canRequest = false;
    this.service.updateEvent(this.thisEvent).subscribe();
    localStorage.setItem("openedEvent", JSON.stringify(this.thisEvent));
  }

  approve() {
    //ako nema niza participanata napravi ga
    if(!this.thisEvent.participants) this.thisEvent.participants = [];
    //
    this.usersToApprove.forEach((element, index) => {
      this.thisEvent.requests.forEach((element2, index2) => {
        if(!element2.localeCompare(element)) {
          //dodaj da ucestvuje
          this.thisEvent.participants.push(element2);
          //izbaci iz requests
          this.thisEvent.requests.splice(index2, 1);
        }
      });
    });
    //
    this.service.updateEvent(this.thisEvent).subscribe();
    localStorage.setItem("openedEvent", JSON.stringify(this.thisEvent));
    //
    this.usersToApprove = [];
  }
}
