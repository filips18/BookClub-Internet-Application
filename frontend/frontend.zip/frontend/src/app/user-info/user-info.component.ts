import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../user.service';
import { MyComment } from '../models/comment';
import { MatTableDataSource } from '@angular/material/table';
import { Book } from '../models/book';
import { MatPaginator } from '@angular/material/paginator';
import { BookService } from '../book.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent implements OnInit {

  constructor(private router: Router, private service: UserService, private bookService: BookService) { }
  @ViewChildren(MatPaginator) paginator = new QueryList<MatPaginator>();
  
  ngOnInit(): void {
    //
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.startDate = this.thisUser.dateOfBirth;
    this.service.getUsers().subscribe(res => this.userArray = res);
    this.bookService.getBooks().subscribe(res => this.bookArr = res); 
    //booksReadDataSource
    this.booksReadDataSource = new MatTableDataSource<Book>(this.thisUser.readBooks);
    //booksReadingDataSource
    this.booksReadingDataSource = new MatTableDataSource<{book : Book, pages: number,pageOn: number}>(this.thisUser.booksBeingRead);
    //booksToReadDataSource
    this.booksToReadDataSource = new MatTableDataSource<Book>(this.thisUser.booksToRead);

    
    //comments
    this.service.getComments().subscribe(res => this.thisUserComments = res);
    let tmpArr: MyComment[] = [];
    setTimeout(() => {
      this.thisUserComments.forEach(element => {
        if(!element.user.localeCompare(this.thisUser.username)) tmpArr.push(element);
        this.thisUserComments = tmpArr;
      });
    }, 200);

    //pie
    let genreArr : string[] = [];
    let dataArr: number[] = [];
    let colorArr: string[] = [];
    this.booksReadDataSource.data.forEach(element => {
      element.genres.forEach(element2 => {
        let toAdd = -1;
        genreArr.forEach((element3, index) => {
          if(!element2.localeCompare(element3)) toAdd = index;
        });
        if(toAdd == -1) {
          genreArr.push(element2);
          dataArr.push(1);
          colorArr.push(this.getRandomColor());
        }
        else  dataArr[toAdd]++;
      });
    });
    //
    let ctx = <HTMLCanvasElement>document.getElementById("myChart");
    let myChart = new Chart(ctx,{
      type: 'pie',
      data: {
          labels: genreArr,
          datasets: [{
              data: dataArr ,
              backgroundColor: colorArr
          }]
      },
      options: {
          maintainAspectRatio: false,
          responsive: true
      }
    });
  }

  ngAfterViewInit() {
    this.booksReadDataSource.paginator = this.paginator.toArray()[0];
    this.booksReadingDataSource.paginator = this.paginator.toArray()[1];
    this.booksToReadDataSource.paginator = this.paginator.toArray()[2];
  }

  thisUser: User;
  thisUserComments: MyComment[] = [];
  startDate: Date;
  columnsToDisplay = ["Title", "Authors", "Genres", "Description"];
  booksReadDataSource: MatTableDataSource<Book>;
  booksReadingDataSource: MatTableDataSource<{book : Book, pages: number,pageOn: number}>;
  booksToReadDataSource: MatTableDataSource<Book>;
  //
  emailInvalid: boolean = false;
  emailTaken: boolean = false;
  userArray: User[] = [];
  //
  bookArr: Book[];
  profilePicture: File = null;

  updatePicture(fs:File[]) {
    this.profilePicture = fs[0];
  }

  saveChanges() {
    this.emailInvalid = false;
    this.emailTaken = false;
    //verif email
    let regexp = new RegExp('[A-Za-z0-9_-]+@[A-Za-z0-9_-]+\\.[a-z]{2,}');
    if(!regexp.test(this.thisUser.email)) {
      this.emailInvalid = true;
    }
    //email zauzet
    this.userArray.forEach(element => {
      if(!element.email.localeCompare(this.thisUser.email) && element.username.localeCompare(this.thisUser.username)) this.emailTaken = true;
    });
    //ako greska, prekini
    if(this.emailInvalid || this.emailTaken) return;
    //uploadFile
    if(this.profilePicture) {
      this.thisUser.profilePicture = "../../assets/profilePictures/" + this.thisUser.username + this.profilePicture.name;
      let uploadOK = false;
      this.service.uploadFile(this.profilePicture, this.thisUser.username).subscribe(res => uploadOK = res);
      /*if(uploadOK) {
        alert("Error while uploading file!");
      }*/
    }
    if(this.startDate) this.thisUser.dateOfBirth = this.startDate;
    //updateUser
    this.service.updateUser(this.thisUser).subscribe();
    //this.ngOnInit();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
  }

  //knjiga
  openBook(bookID : string, comm: MyComment) {
    this.bookArr.forEach(element => {
      if(!element._id.localeCompare(bookID)) {
        localStorage.setItem("openedBook", JSON.stringify(element));
        localStorage.setItem("myComment", JSON.stringify(comm));
      }
    });
  }
  //
  getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
}
