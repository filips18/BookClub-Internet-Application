export class Genre {
    _id?: string;
    name: string;
}