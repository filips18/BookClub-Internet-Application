import { Book } from './book';

export class MyComment {
    _id?: string;
    user: string;
    body: string;
    book: Book;
    stars: number;
}