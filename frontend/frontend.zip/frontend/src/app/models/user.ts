import { Book } from './book';

export class User {
    _id?: string;
    firstName: string;
    lastName: string;
    profilePicture: string;
    username: string;
    password: string;
    dateOfBirth: Date;
    city: string;
    country: string;
    email: string;
    type: string;
    approved: boolean;
    lastLoggedIn: Date;
    readBooks: Book[];
    booksBeingRead: {
        book: Book,
        pages: number,
        pageOn: number
    }[];
    booksToRead: Book[];
    following: string[];
}