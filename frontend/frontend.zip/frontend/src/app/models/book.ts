export class Book {
    _id?: string;
    title: string;
    authors: string[];
    titlePicture: string;
    dateOfPublishing: Date;
    genres: string[];
    description: string;
    approved: boolean;
    averageScore: number;
}