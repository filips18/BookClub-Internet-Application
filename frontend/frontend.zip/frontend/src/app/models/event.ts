export class MyEvent {
    _id?: string;
    name: string;
    startDate: Date;
    endDate?: Date;
    description: string;
    public: boolean;
    madeByUser: string;
    participants: string[];
    requests: string[];
    activities: string[];
    closed: boolean;
}