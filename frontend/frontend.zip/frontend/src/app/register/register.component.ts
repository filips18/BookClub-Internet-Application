import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service: UserService) {
  }

  ngOnInit(): void {
    this.success = false;
    this.service.getUsers().subscribe(users => this.userArray = users);
  }

  userArray: User[];
  newUser: User = new User();
  confirmedPass: string = "";
  //booleans za greske
  emailTaken: boolean = false;
  emailInvalid: boolean = false;
  usernameTaken: boolean = false;
  passwordInvalid: boolean = false;
  passwordsNotMatching: boolean = false;
  validatedCaptcha: boolean = false;
  //booleans za alert
  missingFields: boolean = false;
  success: boolean = false;//= false;
  //slika
  profilePicture: File = null;

  updatePicture(fs:File[]) {
    this.profilePicture = fs[0];
  }

  signup(): void {
    this.missingFields = false;
    this.emailTaken = false;
    this.emailInvalid = false;
    this.passwordInvalid = false;
    this.usernameTaken = false;
    this.success = false;
    this.passwordsNotMatching = false;
    localStorage.removeItem("submittedRequest");

    //nisu svi podaci uneti
    if(!this.validatedCaptcha || this.newUser.firstName == null || this.newUser.lastName == null || this.newUser.city == null || this.newUser.country == null || this.newUser.dateOfBirth == null || this.newUser.email == null || this.newUser.password == null) {
      this.missingFields = true;
      return;
    }
    //regex email
    let regexp = new RegExp('[A-Za-z0-9_-]+@[A-Za-z0-9_-]+\\.[a-z]{2,}');
    if(!regexp.test(this.newUser.email)) {
      this.emailInvalid = true;
    }
    //regex sifra
    if(!/[A-Z]/.test(this.newUser.password) || !/^[a-zA-Z].{6,}$/.test(this.newUser.password) || !/[0-9]/.test(this.newUser.password) || !/[^A-Za-z0-9]/.test(this.newUser.password)){
      this.passwordInvalid = true;
    }
    //confirm sifru
    if(this.confirmedPass.localeCompare(this.newUser.password)) this.passwordsNotMatching = true;
    //username/email nije jedinstven
    this.userArray.forEach(element => {
      if(!element.username.localeCompare(this.newUser.username)) this.usernameTaken = true;
      if(!element.email.localeCompare(this.newUser.email)) this.emailTaken = true;
    });
    //prodji sve pending requests, ako ima neka sa istim email/username, ne dozvoli registraciju
    if(this.usernameTaken || this.emailTaken || this.passwordInvalid || this.emailInvalid || this.passwordsNotMatching) return;
    //posalji zahtev adminu
    if(this.profilePicture == null) {
      this.newUser.profilePicture = "../../assets/profilePictures/defaultProfilePicture.png";
    }
    else { 
      this.newUser.profilePicture = "../../assets/profilePictures/" + this.newUser.username + this.profilePicture.name;
      let uploadOK = false;
      this.service.uploadFile(this.profilePicture, this.newUser.username).subscribe(res => uploadOK = res);
      /*if(uploadOK) {
        alert("Error while uploading file!");
      }*/
    }
    //dodaj ostala polja
    this.newUser.approved = false;
    this.newUser.booksBeingRead = [];
    this.newUser.booksToRead = [];
    this.newUser.readBooks = [];
    this.newUser.following = [];
    this.newUser.lastLoggedIn = new Date();
    this.newUser.type = "user";
    //submit zahtev
    this.service.addUser(this.newUser).subscribe(res => this.success = res);
    this.validatedCaptcha = false;
    grecaptcha.reset()
  }
  //mozda obrisi, dole telo one funkcije je bilo ovde a dole smo zvali ovu funkciju, ali i ovako radi
  sendTokenToBackend(tok){
    //calling the service and passing the token to the service
    
  }

  async resolved(captchaResponse: string) {
    this.service.sendToken(captchaResponse).subscribe(
      data => {
        console.log(data)
      },
      err => {
        console.log(err)
      },
      () => {
        this.validatedCaptcha = true;
      }
    );
  }
}
