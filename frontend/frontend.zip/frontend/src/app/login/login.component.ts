import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../models/user';
import { element } from 'protractor';
import { throwIfEmpty } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  constructor(private userService : UserService, private route: Router) { }

  ngOnInit(): void {
    localStorage.removeItem("loggedInUser");
    this.userService.getUsers().subscribe(users => this.users = users);
  }

  users: User[];
  username: string;
  password: string;
  message: string = "";

  login(): void {
    let found  = false;
    let admin = false;
    let moderator = false;
    this.message = "";
    this.users.forEach(element =>{
      if(!element.username.localeCompare(this.username) && !element.password.localeCompare(this.password) && element.approved) {
        element.lastLoggedIn = new Date();//ovo dodaj u bazu
        this.userService.updateUser(element);
        localStorage.setItem("loggedInUser", JSON.stringify(element));
        found = true;
        if(!element.type.localeCompare("admin")) admin = true;
        if(!element.type.localeCompare("moderator")) moderator = true;
      }
    });
    if(found && !admin && !moderator) {
      this.route.navigateByUrl("user");
    }
    else if (found && admin) this.route.navigateByUrl("admin");
    else if(found && moderator) this.route.navigateByUrl("moderator");
    this.message = "Incorrect username or password.";
  }
}
