import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../event.service';
import { MyEvent } from '../models/event';
import { User } from '../models/user';

@Component({
  selector: 'app-user-events',
  templateUrl: './user-events.component.html',
  styleUrls: ['./user-events.component.css']
})
export class UserEventsComponent implements OnInit {

  constructor(private service: EventService, private router: Router) { }

  ngOnInit(): void {
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    //
    this.service.getEvents().subscribe(res => this.eventArr = res);
    setTimeout(() => {
      this.eventArr.forEach(element => {
        element.startDate = new Date(element.startDate);
        if(element.endDate) element.endDate = new Date(element.endDate);
        if(element.endDate && element.endDate < this.currDate && !element.closed) {
          element.closed = true;
          this.service.updateEvent(element).subscribe();
        }
      });
    }, 100);
  }

  //
  thisUser: User;
  //
  eventArr: MyEvent[] = [];
  currDate: Date = new Date();

  openEvent(event : MyEvent) {
    //
    localStorage.setItem("openedEvent", JSON.stringify(event));
    //
    if(!this.thisUser.type.localeCompare("admin")) {
      this.router.navigateByUrl('admin/admin-event');
    }
    else if(!this.thisUser.type.localeCompare("moderator")) {
      this.router.navigateByUrl('moderator/moderator-event');
    }
    else {
      this.router.navigateByUrl('user/user-event');
    }
    //
  }
}
