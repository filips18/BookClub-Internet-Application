import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Genre } from '../models/genre';
import { Book } from '../models/book';
import { element } from 'protractor';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-genres',
  templateUrl: './admin-genres.component.html',
  styleUrls: ['./admin-genres.component.css']
})
export class AdminGenresComponent implements OnInit {

  constructor(private service: BookService, private router: Router) { }

  ngOnInit(): void {
    this.service.getGenres().subscribe(res => this.genreArr = res);
    this.service.getBooks().subscribe(res => this.bookArr = res);
    this.router.onSameUrlNavigation = 'reload';
  }

  genreArr: Genre[] = [];
  bookArr: Book[] = [];
  genreToAdd: string = "";
  genreToRemove: Genre;

  addGenre() {
    //da li ima vec taj zanr
    let nasao : boolean = false;
    this.genreArr.forEach(element => {
      if(!element.name.localeCompare(this.genreToAdd)) nasao = true;
    });
    if(nasao) {
      alert("Can't add the \"" + this.genreToAdd + "\" genre, it is already in the database.");
      return;
    }
    //dodaj ga
    if(this.genreToAdd == "" || this.genreToAdd == undefined) return;
    let newG : Genre = new Genre();
    newG.name = this.genreToAdd;
    this.service.addGenre(newG).subscribe();
    //
    setTimeout(() => {
      this.service.getGenres().subscribe(res => this.genreArr = res);
      this.router.navigateByUrl('/admin/admin-genres');
    }, 100);
  }

  removeGenre() {
    let nasao : boolean = false;
    if(this.genreToRemove == undefined) return;
    this.bookArr.forEach(element => {
      element.genres.forEach(element2 => {
        if(!element2.localeCompare(this.genreToRemove.name)) nasao = true;
      });
    });
    //
    if(nasao) {
      alert("Can't delete the \"" + this.genreToRemove.name + "\" genre, there are still books in the system with that genre.");
      return;
    }
    else {
      this.service.deleteGenre(this.genreToRemove).subscribe();
    }
    //
    setTimeout(() => {
      this.service.getGenres().subscribe(res => this.genreArr = res);
      this.router.navigateByUrl('/admin/admin-genres');
    }, 100);
  }
}
