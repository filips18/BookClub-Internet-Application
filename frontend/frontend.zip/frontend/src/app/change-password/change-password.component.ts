import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private route: ActivatedRoute, private service: UserService, private route2: Router) { }

  ngOnInit(): void {
    localStorage.removeItem("loggedInUser");
    this.service.getUsers().subscribe(users => this.userArray = users);
  }
  
  userArray: User[];
  confirmedPass: string = "";
  password: string = "";

  
  passwordInvalid: boolean = false;
  passwordsNotMatching: boolean = false;

  changePass() {
    this.passwordsNotMatching = false;
    this.passwordInvalid = false;

    if(!/[A-Z]/.test(this.password) || !/^[a-zA-Z].{6,}$/.test(this.password) || !/[0-9]/.test(this.password) || !/[^A-Za-z0-9]/.test(this.password)){
      this.passwordInvalid = true;
    }

    if(this.password.localeCompare(this.confirmedPass)) this.passwordsNotMatching = true;
    if(this.passwordInvalid || this.passwordsNotMatching) return;

    let userID = this.route.snapshot.paramMap.get('id');
    let updatedUser : User;

    this.userArray.forEach(element =>{
      if(element._id === userID) updatedUser = element;
    });

    if(!updatedUser) {
      console.log("Error while resetting password, undefined user.");
      return;
    }

    updatedUser.password = this.password;

    this.service.updateUser(updatedUser).subscribe();

    //uloguj korisnika
    
    localStorage.setItem("loggedInUser", JSON.stringify(updatedUser));
    if(updatedUser.type == "user") {
      this.route2.navigateByUrl("user");
    }
    else if (updatedUser.type == "admin") this.route2.navigateByUrl("admin");
    else this.route2.navigateByUrl("moderator");
  }

}
