import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from './models/book';
import { Observable } from 'rxjs';
import { Genre } from './models/genre';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http: HttpClient) { }
  
  urlGetBooks = "http://localhost:3000/api/books";
  urlAddBook = "http://localhost:3000/api/book";
  urlPostFile = "http://localhost:3000/api/file2";
  urlUpdateBook = "http://localhost:3000/api/book/";//dodas id knjige na ovo
  //Genres
  urlGetGenres = "http://localhost:3000/api/genres";
  urlAddGenre = "http://localhost:3000/api/genre";
  urlDeleteGenre = "http://localhost:3000/api/genre/";//dodas id zanra na ovo

  //retrieve books
  getBooks(){
    return this.http.get<Book[]>(this.urlGetBooks);
  }
  //add book
  addBook(book : Book){
    return this.http.post<boolean>(this.urlAddBook, book);
  }

  //upload profile picture
  uploadFile(f : File) : Observable<boolean> {
    const formData: FormData = new FormData();
    formData.append('fileKey', f, f.name);
    return this.http
      .post<boolean>(this.urlPostFile, formData);
  }

  //update book
  updateBook(bk: Book) {
    return this.http.put<boolean>(this.urlUpdateBook + bk._id, bk);
  }

  //#Genres
  //get
  getGenres(){
    return this.http.get<Genre[]>(this.urlGetGenres);
  }
  //add
  addGenre(g: Genre){
    return this.http.post<boolean>(this.urlAddGenre, g);
  }
  //delete
  deleteGenre(g: Genre){
    return this.http.delete<boolean>(this.urlDeleteGenre + g._id);
  }
}
