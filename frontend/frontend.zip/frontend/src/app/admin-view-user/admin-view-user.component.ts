import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { BookService } from '../book.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MyComment } from '../models/comment';
import { User } from '../models/user';
import { Book } from '../models/book';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-admin-view-user',
  templateUrl: './admin-view-user.component.html',
  styleUrls: ['./admin-view-user.component.css']
})
export class AdminViewUserComponent implements OnInit {

  constructor(private router: Router, private service: UserService, private bookService: BookService) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit(): void {
    this.thisUser = JSON.parse(localStorage.getItem("openedUser"));
    this.startDate = this.thisUser.dateOfBirth;
    this.service.getUsers().subscribe(res => this.userArray = res);
    this.bookService.getBooks().subscribe(res => this.bookArr = res); 
    //booksReadDataSource
    this.booksReadDataSource = new MatTableDataSource(this.thisUser.readBooks);
    this.booksReadDataSource.paginator = this.paginator;
    //booksReadingDataSource
    this.booksReadingDataSource = new MatTableDataSource(this.thisUser.booksBeingRead);
    this.booksReadingDataSource.paginator = this.paginator;
    //booksToReadDataSource
    this.booksToReadDataSource = new MatTableDataSource(this.thisUser.booksToRead);
    this.booksToReadDataSource.paginator = this.paginator;

    //canFollow
    let loggedInUser : User = JSON.parse(localStorage.getItem("loggedInUser"));
    loggedInUser.following.forEach(element =>{
      if(!element.localeCompare(this.thisUser.username)) this.canFollow = false;
    });
    //

    //comments
    this.service.getComments().subscribe(res => this.thisUserComments = res);
    let tmpArr: MyComment[] = [];
    setTimeout(() => {
      this.thisUserComments.forEach(element => {
        if(!element.user.localeCompare(this.thisUser.username)) tmpArr.push(element);
        this.thisUserComments = tmpArr;
      });
    }, 200);
    //pie chart
    let genreArr : string[] = [];
    let dataArr: number[] = [];
    let colorArr: string[] = [];
    this.booksReadDataSource.data.forEach(element => {
      element.genres.forEach(element2 => {
        let toAdd = -1;
        genreArr.forEach((element3, index) => {
          if(!element2.localeCompare(element3)) toAdd = index;
        });
        if(toAdd == -1) {
          genreArr.push(element2);
          dataArr.push(1);
          colorArr.push(this.getRandomColor());
        }
        else  dataArr[toAdd]++;
      });
    });
    //
    let ctx = <HTMLCanvasElement>document.getElementById("myChart");
    let myChart = new Chart(ctx,{
      type: 'pie',
      data: {
          labels: genreArr,
          datasets: [{
              data: dataArr ,
              backgroundColor: colorArr
          }]
      },
      options: {
          maintainAspectRatio: false,
          responsive: true
      }
    });
    
  }

  thisUser: User;
  thisUserComments: MyComment[] = [];
  startDate: Date;
  columnsToDisplay = ["Title", "Authors", "Genres", "Description"];
  booksReadDataSource: MatTableDataSource<Book>;
  booksReadingDataSource: MatTableDataSource<{book : Book, pages: number, pageOn: number}>;
  booksToReadDataSource: MatTableDataSource<Book>;
  //
  emailInvalid: boolean = false;
  emailTaken: boolean = false;
  userArray: User[] = [];
  //
  canFollow : boolean = true;
  //
  bookArr: Book[];
  //knjiga
  openBook(bookID : string, comm: MyComment) {
    this.bookArr.forEach(element => {
      if(!element._id.localeCompare(bookID)) {
        localStorage.setItem("openedBook", JSON.stringify(element));
        localStorage.setItem("myComment", JSON.stringify(comm));
      }
    });
  }
  //
  getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  //prosledim mu ili 'moderator' ili 'user',  u zavisnosti od kliknutog dugmeta
  changeType(str: string) {
    this.thisUser.type = str;
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("openedUser", JSON.stringify(this.thisUser));
  }
  //
  follow() {
    this.canFollow = false;
    let loggedInUser : User = JSON.parse(localStorage.getItem("loggedInUser"));
    //
    loggedInUser.following.push(this.thisUser.username);
    //
    this.service.updateUser(loggedInUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(loggedInUser));
  }
}
