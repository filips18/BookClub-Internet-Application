import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MyEvent } from './models/event';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(private http: HttpClient) { }

  urlGetEvents = "http://localhost:3000/api/events";
  urlAddEvent = "http://localhost:3000/api/event";
  urlUpdateEvent = "http://localhost:3000/api/event/";//dodajes id na ovo dole u funkcijama

  //get
  getEvents(){
    return this.http.get<MyEvent[]>(this.urlGetEvents);
  }
  //add
  addEvent(e: MyEvent){
    return this.http.post<boolean>(this.urlAddEvent, e);
  }
  //update
  updateEvent(ev: MyEvent) {
    return this.http.put<boolean>(this.urlUpdateEvent + ev._id, ev);
  }
}
