import { Component, OnInit } from '@angular/core';
import { Book } from '../models/book';
import { MyComment } from '../models/comment';
import { UserService } from '../user.service';
import { User } from '../models/user';
import { Router, ActivatedRoute } from '@angular/router';
import { CommentService } from '../comment.service';
import { BookService } from '../book.service';

@Component({
  selector: 'app-user-book',
  templateUrl: './user-book.component.html',
  styleUrls: ['./user-book.component.css']
})
export class UserBookComponent implements OnInit {

  constructor(private service: UserService, private service2: CommentService, private service3: BookService, private router: Router, private activeRouter: ActivatedRoute) { }

  ngOnInit(): void {
    //komentari
    this.service.getComments().subscribe(res => this.commentArr = res);
    //korisnici
    this.service.getUsers().subscribe(res => this.userArr = res);
    //ostalo
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
    this.thisBook = JSON.parse(localStorage.getItem("openedBook"));
    this.myComment = JSON.parse(localStorage.getItem("myComment"));
    if(this.myComment == null) {
      this.hadNoComment = true;
      // da li sme da ostavi kom
      this.thisUser.booksBeingRead.forEach(element => {
        if(element.book._id == this.thisBook._id && element.pageOn/element.pages >= 0.5) this.canLeaveComment = true;
      });
      this.thisUser.readBooks.forEach(element => {
        if(element._id == this.thisBook._id) this.canLeaveComment = true;
      });
      if(!this.thisBook.approved) this.canLeaveComment = false;
      this.myComment = new MyComment;
      this.myComment.user = this.thisUser.username;
      this.myComment.book = this.thisBook;
    }
    else this.canLeaveComment = true;
    //da je ubaci na listu za citanje
    this.thisUser.booksBeingRead.forEach(element =>{
      if(this.thisBook._id == element.book._id) {
        this.canAddToBooksToReadList = false;
        this.pages = element.pages;
        this.pageOn = element.pageOn;
        this.canAddToReadingBooksList = false;
      }
    });
    this.thisUser.readBooks.forEach(element =>{
      if(this.thisBook._id == element._id) {
        this.canAddToReadBooksList = false;
      }
    });
    this.thisUser.booksToRead.forEach(element =>{
      if(this.thisBook._id == element._id) {
        this.canRemoveFromBooksToReadList = false;
      }
    });
    /*this.commentArr.forEach(element => {
      if(!element.book._id.localeCompare(this.thisBook._id)) this.thisBookComments.push(element);
    });*/
  }

  thisUser: User;
  userArr: User[] = [];
  thisBook: Book;
  commentArr: MyComment[];
  myComment: MyComment = null;
  hadNoComment: boolean = false;
  //checks
  canAddToReadBooksList: boolean = true;
  canAddToBooksToReadList: boolean = true;// da je ubaci na listu za citanje, ako je trenutno ne cita
  canRemoveFromBooksToReadList: boolean = false;// da je izbaci iz liste za citanje, ako je trenutno tamo
  canAddToReadingBooksList: boolean = true;// da je oznaci da trenutno cita, samo ako je trenutno ne cita
  //
  canLeaveComment: boolean = false;
  //pbar
  pages: number = 0;
  pageOn: number = 0;
  saveComment(){
    if(this.myComment.stars > 10 || this.myComment.stars < 0) return;
    //prvo nadji kom od ovog lika ako ga ima, ako ne posle ces dodati
    let found = false;
    this.commentArr.forEach((element, index )=> {
      if(!element.user.localeCompare(this.thisUser.username) && element.book._id == this.thisBook._id) {
        this.commentArr[index].stars = this.myComment.stars;
        this.commentArr[index].body = this.myComment.body;
        found = true;
        console.log("IMA, NIJE UBACIO: " + element.user);
      }
    });
    //ubaci ovaj novi kom
    if(!found) {
      console.log("NEMA, UBACIO");
      this.commentArr.push(this.myComment);
    }
    console.log("commentArr nakon trazenja " + this.commentArr);
    //izracunaj novi rejting
    let ratingSum: number = 0;
    let numOfComments : number = 0;
    this.commentArr.forEach(element => {
      if(element.book._id == this.thisBook._id) {ratingSum += element.stars; numOfComments++;}
    })
    //ovo je sad taj rejting
    ratingSum /= numOfComments;
    ratingSum = +ratingSum.toFixed(1);
    //psotavi ga
    this.thisBook.averageScore = ratingSum;
    //update koment i knjigu
    this.service3.updateBook(this.thisBook).subscribe();
    if(this.hadNoComment) {
      this.service2.addComment(this.myComment).subscribe();
    }
    else this.service2.updateComment(this.myComment).subscribe();
    //
    setTimeout(() => {
      localStorage.setItem("myComment", JSON.stringify(this.myComment));
      localStorage.setItem("openedBook", JSON.stringify(this.thisBook));
    } , 100);
    //
    setTimeout(() => {
      this.hadNoComment = false;
    }, 100);
    
    setTimeout( () => {this.ngOnInit()}, 500);
    console.log("ZAV");
  }
  //dodaj u procitane knjige
  readBooks(){
    var elem = <HTMLInputElement>document.getElementById("customSwitch1");
    //dodaj u procitane knjige
    this.thisUser.readBooks.push(this.thisBook);
    //ako je ima, izbaci iz knjiga koje se citaju
    this.thisUser.booksBeingRead.forEach((element, index) =>{
      if(element.book._id == this.thisBook._id) this.thisUser.booksBeingRead.splice(index, 1);
    });
    //ako je ima izbaci iz knjiga koje treba da se citaju
    this.thisUser.booksToRead.forEach((element, index) =>{
      if(element._id == this.thisBook._id) this.thisUser.booksToRead.splice(index, 1);
    });
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
    this.canAddToReadBooksList = false;
    this.ngOnInit();
  }

  //stavi u listu za citanje
  putInBooksToRead() {
    var elem = <HTMLInputElement>document.getElementById("customSwitch2");
    //dodaj u knjige za citanje
    this.thisUser.booksToRead.push(this.thisBook);
    // ako je ima u listi procitanih knjiga izbaci je
    this.thisUser.readBooks.forEach((element, index) =>{
      if(element._id == this.thisBook._id) this.thisUser.readBooks.splice(index, 1);
    });
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
    this.canAddToBooksToReadList = false;
    this.canRemoveFromBooksToReadList = true;
    this.ngOnInit();
  }

  //izvadi iz liste za citanje
  removeFromBooksToRead(){
    var elem = <HTMLInputElement>document.getElementById("customSwitch2");
    // ako je ima u listi  knjiga za citanje izbaci je
    this.thisUser.booksToRead.forEach((element, index) =>{
      if(element._id == this.thisBook._id) this.thisUser.booksToRead.splice(index, 1);
    });
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
    this.canAddToBooksToReadList = true;
    this.canRemoveFromBooksToReadList = false;
    this.ngOnInit();
  }

  //dodaj u listu knjiga koje trenutno cita
  putInReadingBooks(){
    var elem = <HTMLInputElement>document.getElementById("customSwitch3");
    var pages = <HTMLInputElement>document.getElementById("pages");
    var pageOn = <HTMLInputElement>document.getElementById("pageOn");
    if(+pageOn.value > +pages.value) {
      alert("Invalid pages-pageOn relation.");
      return;
    }
    //dodaj u listu knjiga koje se citaju
    this.thisUser.booksBeingRead.push({book: this.thisBook, pages: +pages.value, pageOn: +pageOn.value});
    //ako je ima na listi knjiga za citanje izbaci je
    this.thisUser.booksToRead.forEach((element, index) =>{
      if(element._id == this.thisBook._id) this.thisUser.booksToRead.splice(index, 1);
    });
    //ako je ima na listi procitanih knjiga izbaci je
    this.thisUser.readBooks.forEach((element, index) =>{
      if(element._id == this.thisBook._id) this.thisUser.readBooks.splice(index, 1);
    });
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
    this.canAddToReadingBooksList = false;
    this.ngOnInit();
  }
  //
  editPageOn(){
    var pageOn = <HTMLInputElement>document.getElementById("pageOn2");
    //
    this.thisUser.booksBeingRead.forEach(element => {
      if(element.book._id == this.thisBook._id) {
        if(+element.pages < +pageOn) {
          alert("Invalid pages-pageOn relation.");
          return;
        }
        element.pageOn = +pageOn.value;
        console.log("PAGE ON: " + element.pageOn);
      }
    });
    //
    this.service.updateUser(this.thisUser).subscribe();
    localStorage.setItem("loggedInUser", JSON.stringify(this.thisUser));
    this.ngOnInit();
  }
  //
  openUser(user: string){
    let myUser: User = null;
    this.userArr.forEach(element => {
      if(!element.username.localeCompare(user) && element.username.localeCompare(this.thisUser.username)) myUser = element;
    });
    if(myUser) {
      localStorage.setItem("openedUser", JSON.stringify(myUser));
      this.router.navigate(["user/user-view-user"]);
    }
  }
}
