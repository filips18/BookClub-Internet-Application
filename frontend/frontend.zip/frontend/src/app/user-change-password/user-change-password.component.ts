import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { element } from 'protractor';

@Component({
  selector: 'app-user-change-password',
  templateUrl: './user-change-password.component.html',
  styleUrls: ['./user-change-password.component.css']
})
export class UserChangePasswordComponent implements OnInit {

  constructor(private service: UserService, private route2: Router) {
  }

  ngOnInit(): void {
    this.thisUser = JSON.parse(localStorage.getItem("loggedInUser"));
  }
  
  thisUser: User;
  oldPassword: string = "";
  confirmedPass: string = "";
  password: string = "";

  oldPasswordInvalid: boolean = false;
  passwordInvalid: boolean = false;
  passwordsNotMatching: boolean = false;

  changePass() { //netestirano
    this.passwordsNotMatching = false;
    this.passwordInvalid = false;
    this.oldPasswordInvalid = false;

    if(this.thisUser.password.localeCompare(this.oldPassword)) this.oldPasswordInvalid = true;

    if(!/[A-Z]/.test(this.password) || !/^[a-zA-Z].{6,}$/.test(this.password) || !/[0-9]/.test(this.password) || !/[^A-Za-z0-9]/.test(this.password)){
      this.passwordInvalid = true;
    }

    if(this.password.localeCompare(this.confirmedPass)) this.passwordsNotMatching = true;
    if(this.passwordInvalid || this.passwordsNotMatching || this.oldPasswordInvalid) return;

    let updatedUser = this.thisUser;

    if(!updatedUser) {
      console.log("Error while changing password, undefined user.");
      return;
    }

    updatedUser.password = this.password;

    this.service.updateUser(updatedUser).subscribe();

    //izloguj korisnika
    
    localStorage.removeItem("loggedInUser");
    this.route2.navigateByUrl('');
  }
}
